#!/bin/bash

for file in /usr/share/icons/Numix-Mono/48x48/applications/*
do
    inkscape -f $file --verb=org.inkscape.color.grayscale --verb=FileSave --verb=FileClose
    echo Changed: $file
done
