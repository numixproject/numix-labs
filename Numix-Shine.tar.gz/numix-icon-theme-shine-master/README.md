Numix Shine icon theme
======================

Numix Shine is an icon theme from the [Numix project](http://numixproject.org).

License: GPL-3.0+
