Numix icon theme
================

Numix is the official icon theme from the [Numix project](http://numixproject.org).

It is heavily inspired by, and based upon parts of the Elementary, Humanity and Gnome icon themes.

License: GPL-3.0+
