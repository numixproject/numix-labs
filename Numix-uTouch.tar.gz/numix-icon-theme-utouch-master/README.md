Numix uTouch icon theme
========================

Numix uTouch is an icon theme from the [Numix project](http://numixproject.org).

License: GPL-3.0+
