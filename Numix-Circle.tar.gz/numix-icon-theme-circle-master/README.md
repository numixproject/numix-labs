Numix Circle icon theme
================

Numix Circle is an icon theme from the [Numix project](http://numixproject.org).

License: GPL-3.0+
